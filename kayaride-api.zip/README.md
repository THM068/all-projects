## Feature http-client documentation

- [Micronaut Micronaut HTTP Client documentation](https://docs.micronaut.io/latest/guide/index.html#httpClient)

## Feature ktor documentation

- [Micronaut Ktor documentation](https://micronaut-projects.github.io/micronaut-kotlin/latest/guide/index.html#ktor)

