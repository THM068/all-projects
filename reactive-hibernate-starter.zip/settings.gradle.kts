rootProject.name = "reactive-hibernate-starter"
