package adverity.api

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
